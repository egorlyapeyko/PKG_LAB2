#ifndef MAINWINDOW_H
#define MAINWINDOW_H
// INCLUDE *******************************
#include <QDir>
#include <QImageReader>
#include <QStatusBar>
#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>
#include <QLineEdit>
// ***************************************
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
struct FileData
{
    // Create a data contains my image ***********
    QString Name, Type, Size;
    short Hresolution, Vresolution, Depth, Compression;
    //  ********************************************
};
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QStringList Type_Image, List_Head;
    QString path,rar;
private slots:
    void _FileDirectory();
    void IfInfo();
    void _RAR();
    void IfClose();
private:
    QTableWidget* TableWidget = new QTableWidget(this);
    QString getFileSize(QImage);
    void fillTheTable();
    void settings();
    void fillFromDirectory(QString);
    QTableWidgetItem *item = new QTableWidgetItem;
    QPushButton* Dir_Button = new QPushButton(this);
    QPushButton* Rar_Button = new QPushButton(this);
    QPushButton* Close_Button = new QPushButton(this);
    QPushButton* Info_Button = new QPushButton(this);
    QLineEdit* leDir = new QLineEdit(this);
    QStatusBar* statusbar = new QStatusBar(this);
    Ui::MainWindow *ui;
    QVector <FileData> data_base;
};


#endif // MAINWINDOW_H
