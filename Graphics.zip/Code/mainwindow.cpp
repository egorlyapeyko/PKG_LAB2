#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGridLayout>
#include <QFileDialog>
#include <QHeaderView>
#include <math.h>
#include <QImageWriter>
#include <zipfile.h>
#include <QMessageBox>
#include <zipfile2.h>
#include <QPalette>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    this->setStatusBar(statusbar);
    settings();


    // **COLORS TO MY APP*******************************
    QPalette coloring;
        coloring.setColor(QPalette::Window, QColor(106, 146, 235)); // Установка цвета окна
        coloring.setColor(QPalette::AlternateBase, Qt::black);
        coloring.setColor(QPalette::Base, Qt::black);
        coloring.setColor(QPalette::Text, QColor(13,0,255));
        coloring.setColor(QPalette::Button, Qt::black);
        coloring.setColor(QPalette::ButtonText, QColor(13,0,255));
    qApp->installEventFilter(this);
    // **************************************************




    // SLOTS ********************************************
    connect (this->Dir_Button,SIGNAL(clicked()),SLOT(_FileDirectory()));
    connect (this->Rar_Button,SIGNAL(clicked()),SLOT(_RAR()));
    connect (this->Close_Button,SIGNAL(clicked()),SLOT(IfClose()));
    connect (this->Info_Button,SIGNAL(clicked()),SLOT(IfInfo()));
    // **************************************************
}

void MainWindow::settings()
{

    // ******BUTTON TEXT******************
    this->Rar_Button->setText("Images in RAR");
    this->Dir_Button->setText("Path to image");
    this->Close_Button->setText("Close");
    this->Info_Button->setText("About");
    // ***********************************




    // HEADER WORK *******************************
    Type_Image <<"tif" << "bmp" <<  "pcx" << "png"<< "jpg" << "gif";
    QWidget* window = new QWidget();
    this->setCentralWidget(window);
    this->setFixedWidth(800);
    List_Head << "File Name" << "Type" << "Size" << "Horizontal res (d/i)" << "Vertical res (d/i)" << "Depth" <<"Compression";
    this->TableWidget->setColumnCount(7);
    this->TableWidget->setColumnWidth(0,80);
    this->TableWidget->setHorizontalHeaderLabels(List_Head);
    this->TableWidget->setSortingEnabled(true);
    // *******************************************




    // ******TRIGGERS*************
    this->TableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    this->TableWidget->setSelectionMode(QAbstractItemView::NoSelection);
    this->TableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOff);
    this->TableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOn);
    // ***************************




    this->TableWidget->resizeColumnsToContents();
    this->TableWidget->setContextMenuPolicy(Qt::CustomContextMenu);



    // *****Add buttons********************
    QGridLayout* box = new QGridLayout;
    box->addWidget(this->leDir,2,1);
    box->addWidget(this->Rar_Button,0,2);
    box->addWidget(this->Dir_Button,0,0);
    leDir->setReadOnly(1);
    box->addWidget(this->Close_Button,2,0);
    box->addWidget(this->Info_Button,2,2);
    box->addWidget(this->TableWidget,1,0,1,3);
    window->setLayout(box);
    //*************************************
}

void MainWindow::_FileDirectory()
{
    QFileDialog* Dialog = new QFileDialog(this);
    path = Dialog->getExistingDirectory();
    fillFromDirectory(path);
}

void MainWindow::IfClose()
{
    delete ui;
    exit(0);
}
void MainWindow::IfInfo()
{
  QMessageBox::about(this, "About", "by Egor Liapeiko. Group 14.");
}




// CODE FROM GITHUB. READING ARCHIVES *******************************
void MainWindow::_RAR()
{
    QString fileName = QFileDialog ::getOpenFileName(this, tr("Find archive"),"C:/",tr("zip(*zip)"));
    QFileInfo fileinfo(fileName);


    rar = fileinfo.path();
    QZipReader ZIP(fileName);
    bool check = false;



    if (ZIP.exists()) {
        foreach (QZipReader::FileInfo info, ZIP.fileInfoList()) {
           for (int i=0;i<this->Type_Image.size();i++)
           {
               if(info.filePath.contains(Type_Image[i]))
               {
                   check = true;
                   break;
               }
           }
           if(check)
           {
               break;
           }
        }
        rar=rar+"/temp_folder";
        QDir dir(rar);
        if (!dir.exists())
            dir.mkpath(rar);
        if(check)
        {
            ZIP.extractAll(rar);
            fillFromDirectory(rar);
        }
         dir.removeRecursively();
    }
}
// ***********************************************************







void MainWindow::fillFromDirectory(QString dirPath)
{
    QDir directory(dirPath);
    if(directory.exists())
    {
        QFileInfoList dirContent = directory.entryInfoList(QStringList()
                                          << "*.png" <<"*.jpg"<<"*.tif"<<"*.gif"<<"*.bmp"<<"*.pcx",QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot);
        QImage img;
        QImageWriter writer(dirPath);
        QFileInfo fin;
        this->leDir->setText(dirPath);
        this->data_base.clear();
        for (int i = 0; i < dirContent.size(); i++)
        {
            FileData tmp;
            fin.setFile(dirContent[i].path() + "/" + dirContent[i].fileName());
            img.load(dirContent[i].path() + "/" + dirContent[i].fileName());
            tmp.Name =fin.fileName();
            tmp.Type = "." + fin.suffix();
            tmp.Size = getFileSize(img);
            int q = tmp.Name.size()-1;
            while (tmp.Name[q] != '.')
            {
                q--;
            }
            tmp.Name.remove(q,tmp.Name.size() - q);
            if (ceil(img.dotsPerMeterX()/39.37) - img.dotsPerMeterX()/39.37 >= 0.1)
            {
                tmp.Hresolution = floor(img.dotsPerMeterX()/39.37);
            }
            else
            {
                tmp.Hresolution = ceil(img.dotsPerMeterX()/39.37);
            }

            if (ceil(img.dotsPerMeterY()/39.37) - img.dotsPerMeterY()/39.37 >= 0.1)
            {
                tmp.Vresolution = floor(img.dotsPerMeterY()/39.37);
            }
            else
            {
                tmp.Vresolution = ceil(img.dotsPerMeterY()/39.37);
            }
            tmp.Depth = img.bitPlaneCount();
            tmp.Compression = writer.compression();
            this->data_base.push_back(tmp);
        }
        fillTheTable();
    }
}

void MainWindow::fillTheTable()
{
    this->TableWidget->setRowCount(0);
    for(int i = 0; i < data_base.size(); i++)
    {

        // ** FILL MY TABLE WITH IMAGES **************************
        this->TableWidget->insertRow(i);
        item->setText(data_base[i].Name);
        this->TableWidget->setItem(i,0,new QTableWidgetItem(*item));
        item->setText(data_base[i].Type);
        this->TableWidget->setItem(i,1,new QTableWidgetItem(*item));
        item->setText(data_base[i].Size);
        this->TableWidget->setItem(i,2,new QTableWidgetItem(*item));
        item->setText(QString::number(data_base[i].Hresolution));
        this->TableWidget->setItem(i,3,new QTableWidgetItem(*item));
        item->setText(QString::number(data_base[i].Vresolution));
        this->TableWidget->setItem(i,4,new QTableWidgetItem(*item));
        item->setText(QString::number(data_base[i].Depth));
        this->TableWidget->setItem(i,5,new QTableWidgetItem(*item));
        item->setText(QString::number(data_base[i].Compression));
        this->TableWidget->setItem(i,6,new QTableWidgetItem(*item));
    }
    this->TableWidget->sortByColumn(0,Qt::AscendingOrder);
    // *********************************************************************
}

QString MainWindow::getFileSize(QImage img)
{

    QSize ____size = img.size();
    QString result = QString::number(____size.width())+"×"+QString::number(____size.height());
    return result;
}





MainWindow::~MainWindow()
{
    delete ui;
}
